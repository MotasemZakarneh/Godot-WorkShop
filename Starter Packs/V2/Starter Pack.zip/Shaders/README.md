# Sprite Shaders

This is a sample consisting of different shaders applied to some sprites.
Effects include outlines, blurs, distorts, shadows, glows, and more.

Language: [GDSL](https://docs.godotengine.org/en/latest/tutorials/shading/shading_reference/shading_language.html)

Renderer: GLES 2

## Screenshots

![Screenshot](screenshots/sprite.png)
