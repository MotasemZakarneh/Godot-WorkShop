Spaceships Set (1.0)

Created and Distributed by Wisedawn (https://wisedawn.itch.io/)
Creation Date: 01/03/2019

-----------------------------------------------------------------------------

License: (Creative Commons Zero, CC0)
http://creativecommons.org/publicdomain/zero/1.0/

This content is free to use in personal, educational and commercial projects.

Support us by crediting Wisedawn (this is not mandatory).

-----------------------------------------------------------------------------

Follow on Twitter for updates:
https://twitter.com/wisedawndev